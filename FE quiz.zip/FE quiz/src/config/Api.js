

const api = "http://localhost:4001/api";

export default api